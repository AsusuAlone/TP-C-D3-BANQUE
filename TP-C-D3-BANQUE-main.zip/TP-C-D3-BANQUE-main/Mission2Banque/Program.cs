﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mission2Banque
{
    class Program
    {
        static void Main(string[] args)
        {
            Banque b = new Banque();
            Compte c = new Compte(50, "Eric", 1500, -500);
            Compte c1 = new Compte(49, "Sam", 2500, -500);
            if(c1.Transfere(1500, c))
            {
                Console.WriteLine("La somme a bien été transféré");
            }
            else
            {
                Console.WriteLine("La somme n'a pas été transféré");
            }
            Console.WriteLine(c1.ToString());
            Console.ReadKey();
        }
    }
}
